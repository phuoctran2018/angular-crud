export interface Comment {
    id: number;
    comment: string;
    postID: number
}