export interface Post {
    id: number;
    body: string;
}